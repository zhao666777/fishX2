---
name: fishx2-xiaohongshu-publisher
description: Turn raw notes, product descriptions, screenshots, transcripts, or rough ideas into an approval-ready Xiaohongshu content package: factual extraction, hook and title, polished post copy, a 4–6 page storyboard, comment prompt, tags, and claim guardrails. Use for Xiaohongshu/Rednote post planning, title writing, copy optimisation, content repurposing, carousel planning, or whenever the user asks to turn material into a publishable Chinese social post.
---

# Fish×2 Xiaohongshu Publisher

Create a complete approval-first Xiaohongshu package. Default goal: build brand awareness and earn saves/follows, not hard conversion.

## Read first

Read `references/editorial-policy.md` before drafting. It contains the approved voice, decision defaults, factual guardrails, and output format.

## Workflow

1. Extract only established facts: capability, audience, delivery, proof, and limits. Do not invent metrics, effects, compatibility, or guarantees.
2. Select one strongest narrative without asking the user to choose. Use: pain point → turn → solution → benefit/proof → action.
3. Draft the approval package in the required output order from the reference.
4. Default to five cards. Compress to four for simple ideas; expand to six for complex ideas. Each card carries one point and has a clear visual role.
5. Stop after the copy-and-storyboard package. Do not generate illustrations or layout until the user approves the storyboard.
6. After approval, hand the approved storyboard to `fishx2-illustrations` for distinct scene-based illustrations, then to `guizang-social-card-skill` for magazine-style 3:4 layout.
7. Treat approval as authority to finish illustration assets, layout, 1080×1440 PNG export, visual verification, and final links. Do not pause after source art or present intermediate assets as delivery.

## Decision rule

Make normal editorial decisions autonomously. Ask one concise question only when one of these changes the truthful or strategic outcome:

- the objective is not brand awareness/saves/follows;
- a claim, compatibility statement, price, or delivery promise is unverified;
- public disclosure could create a brand, legal, or commercial risk.

Otherwise publish the best single recommendation, plus two alternate titles only. Do not present multiple narrative directions for the user to select.

## Image rules after approval

Fish×2 is the default illustration IP for every topic unless the user explicitly opts out. Use different scene illustrations across cards; never shrink and repeat one illustration as filler. Preserve the Fish×2 character rules. Use the magazine layout system with harmonious extraction of the IP's cobalt blue, yellow, hot pink, and orange accents.

## Quality bar

- Prefer clear conversational Chinese over advertising jargon or exaggerated internet slang.
- Keep the tone real, lightly playful, technically grounded, and never overly cute.
- Separate established facts from suggested wording in the claim guardrail section.
- Write cover hooks for a glance; put nuance in later cards and the post body.
- Keep card text readable on mobile. Do not turn a carousel into a long article.
- Only mark work complete when the final ordered 3:4 PNG card set is delivered. If a stage fails, state the concrete blocker and continue with the next safe recovery step.
