# Editorial Policy

## Defaults

- Goal: brand awareness plus saves/follows.
- Voice: real-person sharing; light, candid, and technically grounded. Use the spirit of “手搓” and “不玄学” when it fits. Avoid hard-sell language, exaggerated hype, and dense platform slang.
- Output one recommended direction and two title alternatives. Do not make the user choose between narratives.
- Use Fish×2 as the default illustration IP for all subjects. The user reviews copy/storyboard before illustration and layout are generated.

## Required approval package

1. **Core narrative** — one sentence: pain → turn → solution → benefit → action.
2. **Fact sheet** — capability, audience, delivery, limitations, and unknowns.
3. **Cover hook** — one recommended hook plus two alternate titles.
4. **Post copy** — ready-to-publish caption with short paragraphs and a natural closing prompt.
5. **Carousel storyboard** — 4, 5, or 6 cards; each lists the visible title, concise text, and visual intent. Default to five.
6. **Comment prompt and tags** — relevant rather than generic.
7. **Claim guardrails** — separate source-supported claims from suggested wording; explicitly flag missing proof or risky promises.

## Storyboard sizing

- 4 cards: one simple promise or short checklist.
- 5 cards: default — cover, pain, solution, proof/benefits, action.
- 6 cards: complex tutorial, comparison, or multi-part proof.

## Fact guardrails

- Never state a result, metric, compatibility claim, price, time claim, or guarantee unless supplied or explicitly confirmed.
- Phrase unverified interpretation as an angle or suggestion, not fact.
- If a missing fact would materially change the message, ask one consolidated question before writing final copy.
